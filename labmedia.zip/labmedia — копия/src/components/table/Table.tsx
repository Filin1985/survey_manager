import { useState, useMemo } from "react"
import styles from "./table.module.scss"
import TableRow from "./table-row/TableRow"
import Paginate from "../pagination/Pagination"
import { useSelector, useDispatch } from "../../services/hooks"

const PAGE_SIZE = 5

const Table = () => {
  const dispatch = useDispatch()
  const {
    isFilteredByDate,
    isFilteredByRating,
    dateFilteredUser,
    ratingFilteredUser,
  } = useSelector((store) => store.userData)
  const { users } = useSelector((store) => store.userData)
  const [currentPage, setCurrentPage] = useState(1)
  const [postsPerPage] = useState(PAGE_SIZE)

  const indexOfLastPost = currentPage * postsPerPage
  const indexOfFirstPost = indexOfLastPost - postsPerPage
  const currentPosts = isFilteredByDate
    ? dateFilteredUser.slice(indexOfFirstPost, indexOfLastPost)
    : isFilteredByRating
    ? ratingFilteredUser.slice(indexOfFirstPost, indexOfLastPost)
    : users.slice(indexOfFirstPost, indexOfLastPost)

  const paginate = (pageNumber: number) => {
    setCurrentPage(pageNumber)
  }

  const previousPage = () => {
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1)
    }
  }

  const nextPage = () => {
    if (currentPage !== Math.ceil(users.length / postsPerPage)) {
      setCurrentPage(currentPage + 1)
    }
  }

  return (
    <>
      <table className={styles.table}>
        <thead>
          <tr>
            <th className={styles.table__head}>Имя пользователя</th>
            <th className={styles.table__head}>E-mail</th>
            <th className={styles.table__head}>Дата регистрации</th>
            <th className={styles.table__head}>Рейтинг</th>
            <th className={styles.table__head}></th>
          </tr>
        </thead>
        <tbody>
          {users.length > 0 && (
            <>
              {currentPosts.map((user) => (
                <TableRow
                  key={user.id}
                  id={user.id}
                  username={user.username}
                  email={user.email}
                  registration_date={user.registration_date}
                  rating={user.rating}
                />
              ))}
            </>
          )}
        </tbody>
      </table>
      <Paginate
        postsPerPage={postsPerPage}
        totalPosts={users.length}
        paginate={paginate}
        previousPage={previousPage}
        nextPage={nextPage}
      />
    </>
  )
}

export default Table
