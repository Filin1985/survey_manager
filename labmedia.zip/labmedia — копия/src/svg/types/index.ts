export interface IIcon {
  onClick?: (e: React.MouseEvent<HTMLOrSVGElement>) => void
  style?: object
}
